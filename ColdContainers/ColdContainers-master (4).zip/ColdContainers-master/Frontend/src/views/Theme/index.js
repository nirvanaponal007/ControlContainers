import Colors from './Colors';
import Typography from './Typography';

export {
  Colors, Typography,
};