module.exports = {
    //AMBIENT : '192.168.0.104',
    //AMBIENT : 'localhost',
   
    //AMBIENT : '3.236.160.141',
    AMBIENT : '3.85.211.106', // windows server amz
    // AMBIENT : '190.145.2.214',
    //  AMBIENT : '34.250.44.147',
    
	
	// AMBIENT : '100.20.189.226',
    PORT: process.env.port || 3000,
    PORT_MQTT: process.env.port || 1884,
}

