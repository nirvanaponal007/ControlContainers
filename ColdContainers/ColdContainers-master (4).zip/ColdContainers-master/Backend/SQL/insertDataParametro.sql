use griosb_desa_coldcontainers;

insert into tbl_parametros  set par_clave='TimeSend', par_valor=10;