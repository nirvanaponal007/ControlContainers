use griosb_desa_coldcontainers;

ALTER TABLE tbl_cliente
ADD COLUMN cli_eliminado INT default 0;

