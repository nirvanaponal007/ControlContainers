ALTER TABLE `griosb_desa_coldcontainers`.`tbl_usuario` 
CHANGE COLUMN `usu_eliminado` `usu_eliminado` INT(11) NULL DEFAULT 0 ;