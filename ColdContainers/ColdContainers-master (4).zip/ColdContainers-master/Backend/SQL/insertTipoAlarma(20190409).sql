use griosb_desa_coldcontainers;

insert into tbl_tipo_alarma(tala_descripcion,tala_estado) values
('Normal',1),
('Leve',1),
('Moderada',1),
('Critica',1);