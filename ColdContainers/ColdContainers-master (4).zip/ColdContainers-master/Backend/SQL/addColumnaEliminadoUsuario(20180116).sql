use griosb_desa_coldcontainers;
ALTER TABLE tbl_usuario
ADD COLUMN usu_eliminado INT;