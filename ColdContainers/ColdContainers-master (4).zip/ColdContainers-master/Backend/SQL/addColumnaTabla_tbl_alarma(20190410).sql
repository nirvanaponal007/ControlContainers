use griosb_desa_coldcontainers;

ALTER TABLE tbl_alarma ADD COLUMN ala_usu_id int(11);
ALTER TABLE tbl_alarma ADD COLUMN ala_con_id int(11);