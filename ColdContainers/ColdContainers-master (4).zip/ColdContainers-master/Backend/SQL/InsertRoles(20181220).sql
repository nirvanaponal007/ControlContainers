use griosb_desa_coldcontainers;
insert into tbl_rol(rol_descripcion,rol_estado) 
values 
('administrador',1),
('usuario',1);