use griosb_desa_coldcontainers;
ALTER TABLE tbl_contenedor ADD con_descripcion varchar(1000);